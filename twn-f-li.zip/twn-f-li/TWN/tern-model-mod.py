#!/usr/bin/env python

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import argparse
import os
import warnings

import numpy as np
import tensorflow as tf
from tensorflow.python.framework import ops

import time
start_time = time.time()


logs_path="/tmp/tensorflow_logs/example/"

def compute_threshold(x):
    # x_max=tf.reduce_max(x,reduce_indices= None, keep_dims= False, name= None)
    x_sum = tf.reduce_sum(tf.abs(x),reduction_indices= None, keepdims =False ,name= None)
    threshold = tf.div(x_sum,tf.cast(tf.size(x), tf.float32),name= None)
    threshold = tf.multiply(0.7,threshold,name= None)
    return threshold


def compute_alpha(x):
    threshold = compute_threshold(x)
    alpha1_temp1 = tf.where(tf.greater(x,threshold), x, tf.zeros_like(x, tf.float32))
    alpha1_temp2 = tf.where(tf.less(x,-threshold), x, tf.zeros_like(x, tf.float32))
    alpha_array = tf.add(alpha1_temp1,alpha1_temp2,name = None)
    alpha_array_abs = tf.abs(alpha_array)
    alpha_array_abs1 = tf.where(tf.greater(alpha_array_abs,0),tf.ones_like(alpha_array_abs,tf.float32), tf.zeros_like(alpha_array_abs, tf.float32))
    alpha_sum = tf.reduce_sum(alpha_array_abs)
    n = tf.reduce_sum(alpha_array_abs1)
    alpha = tf.div(alpha_sum,n)
    return alpha



def tenary_opration(x):
    """
    Clip and ternarises tensor using the straight through estimator (STE) for the gradient.
    # """
    threshold =compute_threshold(x)
    x=tf.sign(tf.add(tf.sign(tf.add(x,threshold)),tf.sign(tf.add(x,-threshold))))   #Good way for the repersentation. When threshold it positive it will form a Ternary Function.
    return x






def add_tern_layer(prev_layer, num_outputs, uid):
    """Adds a binary layer to the network.

    Args:
        prev_layer:    2D Tensor with shape (batch_size, num_hidden).
        num_outputs:   int, number of dimensions in next hidden layer.
        inference:     bool scalar Tensor, tells the network if it is
                       the inference step.
        uid:           int, the unique identifier.

    Returns:
        tuple (activation, updates)
            activation:     output of this layer.
            updates:        variables used to compute gradients.
    """

    batch_size, num_inputs = [dim.value for dim in prev_layer.get_shape()]


    def _pos_neg_like(tensor):
        return (tf.constant(1, dtype=tf.float32, shape=tensor.get_shape()),
                tf.constant(-1, dtype=tf.float32, shape=tensor.get_shape()))




    with tf.variable_scope('tern_layer_%d' % uid) as vs:
        w = tf.get_variable('w', shape=(num_inputs, num_outputs),
                            initializer=tf.random_normal_initializer(seed=uid),
                            trainable=True)

        


        alpha_w = compute_alpha(w)

        ter_w = tf.multiply(alpha_w, w ,name = None)

        #Ternarising the Weight Matrix
        ter_w = tenary_opration(w)


        # Output has shape (batch_size, num_outputs)

        wx = tf.matmul(prev_layer, ter_w)

        with tf.variable_scope('activation'):
            # p = tf.tanh(wx) #If changed to Htanh the algorithm become same as that explained in the paper. Using the Straight Through Estimator
            p=tf.clip_by_value(wx,-1,1)


           
            

            activation =tf.where(wx > 0, *_pos_neg_like(wx))  # Deterministic inference.


        return activation, (p, prev_layer, w, ter_w)






def add_binary_layer(prev_layer, num_outputs, uid):
    """Adds a binary layer to the network.

    Args:
        prev_layer:    2D Tensor with shape (batch_size, num_hidden).
        num_outputs:   int, number of dimensions in next hidden layer.
        inference:     bool scalar Tensor, tells the network if it is
                       the inference step.
        uid:           int, the unique identifier.

    Returns:
        tuple (activation, updates)
            activation:     output of this layer.
            updates:        variables used to compute gradients.
    """

    batch_size, num_inputs = [dim.value for dim in prev_layer.get_shape()]

    def _pos_neg_like(tensor):
        return (tf.constant(1, dtype=tf.float32, shape=tensor.get_shape()),
                tf.constant(-1, dtype=tf.float32, shape=tensor.get_shape()))

    with tf.variable_scope('binary_layer_%d' % uid) as vs:
        w = tf.get_variable('w', shape=(num_inputs, num_outputs),
                            initializer=tf.random_normal_initializer(seed=uid),
                            trainable=True)

        #Lets use the actual signum function if the weights is 0 conver it to 0
        # bin_w=tf.where(w==0, tf.constant(0,dtype=tf.float32, shape=(num_inputs, num_outputs)),tf.matmul(w,tf.Variable(initial_value = np.identity(num_outputs),dtype=tf.float32)))

        # Binarize the weight matrix.
        bin_w = tf.where(w > 0, *_pos_neg_like(w))

        # Output has shape (batch_size, num_outputs)
        wx = tf.matmul(prev_layer, bin_w)

        with tf.variable_scope('activation'):
            # p = tf.tanh(wx) #If changed to Htanh the algorithm become same as that explained in the paper.
            p=tf.clip_by_value(wx,-1,1)


            def _binomial_activation():
                sigma = tf.random_uniform(
                    p.get_shape(), seed=uid) < (p + 1) / 2
                return tf.where(sigma, *_pos_neg_like(p))

            def _binary_activation():
                return tf.where(wx > 0, *_pos_neg_like(wx))

            activation = tf.where(wx > 0, *_pos_neg_like(wx))  # Deterministic inference.

        return activation, (p, prev_layer, w, bin_w)


def build_model(input_var, layers=[]):
    """Builds a BNN model.

    Args:
        input_var:     2D Tensor with shape (batch_size, num_input_features).
        layers:        list of ints, the dimensionality of each layer.

    Returns:
        tuple (output_layer, updates, inference)
            output_layer:    2D Tensor, the output of the model.
            updates:         list of variables used to compute gradients.
            inference:       scalar bool Tensor, used to tell the model when to
                             use inference mode.
    """

    updates = []
    hidden_layer = input_var
    for i, num_hidden in enumerate(layers):
        hidden_layer, update = add_tern_layer(hidden_layer, num_hidden, i)
        updates.append(update)
    output_layer = hidden_layer

    return output_layer, updates


#Since we wish the activation of the layer be binary and the weights to be ternary.



def build_last(input_var, num_hidden, layers_size, updates):
    """Builds a BNN model.

    Args:
        input_var:     2D Tensor with shape (batch_size, num_input_features).
        layers:        list of ints, the dimensionality of each layer.

    Returns:
        tuple (output_layer, updates, inference)
            output_layer:    2D Tensor, the output of the model.
            updates:         list of variables used to compute gradients.
            inference:       scalar bool Tensor, used to tell the model when to
                             use inference mode.
    """

    
    hidden_layer = input_var
    i=layers_size
    hidden_layer, update = add_binary_layer(hidden_layer, num_hidden,
                                                i)
    updates.append(update)
    output_layer = hidden_layer

    return output_layer, updates


def get_loss(output, target):
    return tf.reduce_mean(tf.square(output - target))


def get_accuracy(output, target, element_wise=True):
    if not element_wise:
        output, target = tf.reduce_sum(output, [1]), tf.reduce_sum(target, [1])
    eq = tf.equal(tf.greater(output, 0), tf.greater(target, 0))
    return tf.reduce_mean(tf.cast(eq, tf.float32))


def binary_backprop(loss, output, updates):
    """Manually backpropagates gradient error.

    Args:
        loss:         scalar Tensor, the model loss.
        output:       scalar
        updates:      list of updates to use for backprop.

    Returns:
        backprop_updates:  list of (grad, variable) tuples, the gradients.
    """

    backprop_updates = []
    loss_grad, = tf.gradients(loss, output)

    for p, prev_layer, w, trin_w in updates[::-1]:
        w_grad, loss_grad = tf.gradients(p, [trin_w, prev_layer], loss_grad) #dc_dw, dc_db = tf.gradients(cost, [W, b])
        backprop_updates.append((w_grad, w))

    return backprop_updates


def save_model(path, binary_weights):
    with open(os.path.join(path, 'model.def'), 'w') as f:
        f.write('bnn')
        for i, weight in enumerate(binary_weights):
            weight = weight.T
            f.write('\n%d,%d\n' % (weight.shape[1], weight.shape[0]))
            bstr = '\n'.join(''.join('0' if e < 0 else '1' for e in r)
                             for r in weight)
            f.write(bstr)
        f.write('\n0,0')


def main():
    parser = argparse.ArgumentParser(
        description='Train binary neural network weights.')
    parser.add_argument(
        '--save_path',
        type=str,
        help='Where to save the weights and configuration.',
        required=True)
    parser.add_argument(
        '--num_train',
        type=int,
        help='Number of iterations to train model.',
        default=20000)
    parser.add_argument(
        '--eval_every',
        type=int,
        help='How often to evalute the model.',
        default=1000)

    parser.add_argument(
        '--bench_tt',
        type=str,
        help='The text file which include the truth table of the Benchmark',
        required=True)
    args = parser.parse_args()

   
    
    #File Handling for Benchmark Analysis

    file=open(args.bench_tt,'r') #Opening File for reading.
    temp_str=str(file.readline())
    Nx,Ny=(temp_str.split(','))
    Nx=int(Nx) #It is the number of the inputs. 
    Ny=int(Ny) #It is the number of outputs.

    input_data = np.zeros(shape=(2**Nx,Nx ))
    output_data = np.zeros(shape=(2**Nx, Ny))

    for i in range(2**Nx):
        inp,out=file.readline().split(',')
        inp=list(inp)
        out=list(out)
        out=out[:Ny]
        input_data[i]=map(int,inp)
        output_data[i]=map(int,out)



    file.close()



    #The graph inputs
    input_var = tf.placeholder(dtype=tf.float32, shape=(2**Nx,Nx),
                               name='input_placeholder')

    output_var = tf.placeholder(dtype=tf.float32, shape=(2**Nx,Ny),
                                name='output_placeholder')
    

    inc_layer_sizes=[0,0,0,0]

    layer_sizes = [5,5,3,2]  # Need to write the output layer number too.

    num_layer_sizes=len(layer_sizes)


    layers_size.append(Ny)#The Number of Output Neurons
    


    #Convert to Bipolar

    input_data=input_data*2-1;
    output_data=output_data*2-1;
    print(input_data)
    print(output_data)

    dataset=np.concatenate((input_data,output_data),axis=1)

    summary=tf.summary.merge_all()

    feed_dict = {
        input_var: input_data,
        output_var: output_data,
    }

    model_scope = 'model'
    with tf.variable_scope(model_scope):

        output_layer, updates = build_model(input_var, layers=layer_sizes)



        # output_layer, updates =build_last(output_layer_prev,Ny,len(layer_sizes),updates)

        model_vars = tf.get_collection(tf.GraphKeys.VARIABLES,
                                       scope=model_scope)

        loss = get_loss(output_layer, output_var)

        accuracy = get_accuracy(output_layer, output_var)

    global_step = tf.Variable(0, name='global_step', trainable=False)
    learning_rate = 0.001

    gradients = binary_backprop(loss, output_layer, updates)

    optimizer = tf.train.GradientDescentOptimizer(learning_rate=learning_rate)

    min_op = optimizer.apply_gradients(gradients, global_step=global_step)

    # Get model weights.
    _, _, _, weights = zip(*updates)

    best_accuracy = 0
    with tf.Session() as sess:
        sess.run(tf.global_variables_initializer())
        writer = tf.summary.FileWriter(logs_path, graph=tf.get_default_graph())

        for i in xrange(1, args.num_train + 1):
            np.random.shuffle(dataset)
            input_data,output_data=np.hsplit(dataset,[Nx])

            feed_dict = {
            input_var: input_data,
            output_var: output_data,
                         }

      

            sess.run([min_op], feed_dict=feed_dict)
            if i % args.eval_every == 0:

                np.random.shuffle(dataset)
                input_data,output_data=np.hsplit(dataset,[Nx])
                
                feed_dict = {
                input_var: input_data,
                output_var: output_data,
                             }

                
                accuracy_val, loss_val = sess.run([accuracy, loss],
                                                  feed_dict=feed_dict)
                print('Epoch = %d: Loss = %.4f, Accuracy = %.4f' %
                      (i, loss_val, accuracy_val))

                if accuracy_val > best_accuracy:
                    # for entry in sess.run(output_layer, feed_dict=feed_dict):
                    #     out_str = ''.join('0' if i <= 0 else '1' for i in entry)
                    #     # out_str=''.join()
                    #     print(out_str[::-1])
                    # print('The output data is:')
                    # print((output_data+1)/2)
                    # save_model(args.save_path, sess.run(weights))
                    # best_accuracy = accuracy_val

                    output_val=sess.run(output_layer, feed_dict=feed_dict)
                    print('The output Layer Values are')
                    print((output_val+1)/2)
                    print('The output in the Feed dict i.e the Target')
                    print((output_data+1)/2)
                    best_accuracy = accuracy_val 

                    weights_mat=sess.run(weights)

                    print('The weights Matrix')

                    # print(weights_mat)       
                    for m, weight_t in enumerate(weights_mat):
                          weight_t = weight_t.T
                          print('\n%d,%d\n' % (weight_t.shape[1], weight_t.shape[0]))
                          for e in weight_t:
                            print(e)
                          





    print("--- %s seconds ---" % (time.time() - start_time))
    print('Best Accuracy is ')
    print(best_accuracy)


if __name__ == '__main__':
    main()

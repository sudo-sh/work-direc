#ifndef _MAP_H_
#define _MAP_H_

#include "global.h"

typedef struct {
  long first_index;
  long second_index;
  long step;
} index_seq_type;

typedef struct {
  long first_index;
  long second_index;
  std::vector<long> seq_indexes;
  long num_repeat;
} seq_seq_type;


int map_names(pstr_vec &first_names, pstr_vec &second_names, pstr_map &names_map, std::vector<long> &first_to_second_map);


int seq_indexes(std::vector<long> &first_to_second_map, std::vector<index_seq_type> &indexes_seq);

int seq_sequences(std::vector<index_seq_type> &indexes_seq, std::vector<seq_seq_type> &sequences_seq);

#endif

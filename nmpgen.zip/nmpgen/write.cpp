#include "write.h"

#include <fstream>

using namespace std;

int write_python(string filename, stringstream &python_str) {
  ofstream pyfile(filename.c_str());
  if (!pyfile.good())
    return -1;

  pyfile << python_str.rdbuf();
    
  pyfile.close();
  
  return 0;
}

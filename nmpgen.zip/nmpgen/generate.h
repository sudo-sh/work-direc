#ifndef _GEN_H_
#define _GEN_H_

#include "global.h"
#include "map.h"

#include <sstream>
#include <iostream>

long generate_python(std::stringstream &python_str, std::vector<index_seq_type> &indexes_seq, std::vector<seq_seq_type> &sequences_seq, long last_index_plus, int sort_way);
long generate_python_n(std::stringstream &python_str, std::vector<index_seq_type> &indexes_seq, std::vector<seq_seq_type> &sequences_seq, std::vector<long> &except_neq_indexes, long last_index_plus, int sort_way);
long generate_python_s(std::stringstream &python_str, std::vector<index_seq_type> &indexes_seq, std::vector<seq_seq_type> &sequences_seq, std::vector<long> &except_neq_indexes, std::vector<long> &except_indexes, long last_index_plus, int sort_way);

// TODO: you may add your own function or modify the existing function
//       however, the output should be stringstream and should return the number of non-space characters

#endif

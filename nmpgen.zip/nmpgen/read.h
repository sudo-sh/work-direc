#ifndef _READ_H_
#define _READ_H_

#include "global.h"

int read_names(std::string filename, pstr_vec &first_names, pstr_vec &second_names, pstr_map &names_map);

#endif

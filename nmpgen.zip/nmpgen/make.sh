g++ -O3 main.cpp map.cpp generate.cpp sort.cpp solution.cpp read.cpp write.cpp -o nmpgen

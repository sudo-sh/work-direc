#ifndef _WRITE_H_
#define _WRITE_H_

#include "global.h"
#include <sstream>

int write_python(std::string filename, std::stringstream &python_str);

#endif

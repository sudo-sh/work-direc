import sys,json,re
A=json.load(open(sys.argv[1]))
B=set(A[1])
A=set(A[0])
C=A&B
E=[]
D=[]
G=sorted(B^C)
F=sorted(A^C)
H=[F[i] for i in [25281,25303]]
j=0
for s in F:
  l=len(s)
  while j<len(G)-1 and G[j]<s: j+=1
  k=j
  t=G[k]
  while l<len(t) and s==t[:l]:
    if not t[l].isalnum() and s not in H:
      D+=[s]
      E+=[t]
      break
    k+=1
    t=G[k]
T=lambda x: re.sub('(\d+)',lambda y: y.group().zfill(9),x)
B=sorted(set(G)^set(E),key=T)
A=sorted(set(F)^set(D),key=T)
C=sorted(C)
F=B[:64]
G=B[185:249]
H=B[368:432]
I=B[1286:1304]
J=B[1304:1338]
Z=B[64:98]+F[1::4]+F[3::4]+F[::4]+F[2::4]+B[98:185]+B[249:283]+G[1::4]+G[3::4]+G[::4]+G[2::4]+B[283:368]+B[432:466]+H[1::4]+H[3::4]+H[::4]+H[2::4]+B[466:1286]+B[-10:-6]+B[1338:-95]+I[1::4]+J[2::3]+I[3::4]+J[::3]+I[::4]+J[1::3]+I[2::4]+B[-95:-10]+B[-6:]
json.dump(dict(zip(C+D+A,C+E+Z)),open(sys.argv[2],'w'))

#include "read.h"

#include <fstream>

using namespace std;

const int max_str_size = 512;

int read_names(string filename, pstr_vec &first_names, pstr_vec &second_names, pstr_map &names_map) {
  ifstream mapfile(filename.c_str());
  if (!mapfile.good())
    return -1;

  string first_str_org;
  string second_str_org;
  first_str_org.reserve(max_str_size);
  second_str_org.reserve(max_str_size);
  char curc;
  mapfile.get(curc);
  while(mapfile.good()) {
    first_str_org.clear();
    second_str_org.clear();
    while(curc != '\"')
      mapfile.get(curc);
    mapfile.get(curc);
    while(curc != '\"') {
      first_str_org.push_back(curc);
      mapfile.get(curc);
    }
    mapfile.get(curc);
    while(curc != '\"')
      mapfile.get(curc);
    mapfile.get(curc);
    while(curc != '\"') {
      second_str_org.push_back(curc);
      mapfile.get(curc);
    }
    mapfile.get(curc);

    string* fstr = new string(first_str_org);
    string* sstr = new string(second_str_org);
    first_names.push_back(fstr);
    second_names.push_back(sstr);
    names_map[fstr] = sstr;
    
    while(curc != '\"' && mapfile.good())
      mapfile.get(curc);
  }
  
  mapfile.close();

  return 0;
}

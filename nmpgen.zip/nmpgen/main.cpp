#include <cstdio>
#include <cstdlib>

#include <iostream>

#include "global.h"
#include "read.h"
#include "write.h"
#include "solution.h"

using namespace std;


int main(int argc, char* argv[]) {
  if (argc != 3)
    return 1;

  pstr_vec first_names;
  pstr_vec second_names;
  pstr_map names_map;
  read_names(argv[1], first_names, second_names, names_map);



  // TODO: exploring more solutions needs calling other solution functions
  //       and finally writing the "best" one in the output file!
  string main_str;
  stringstream python_str(main_str);
  long char_cnt = sol_simple(python_str, first_names, second_names, names_map);
  cout << "python char count is: " << char_cnt << endl;


  
  write_python(argv[2], python_str);

  return 0;
}

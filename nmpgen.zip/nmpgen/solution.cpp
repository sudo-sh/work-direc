#include "solution.h"

#include "generate.h"
#include "sort.h"
#include "map.h"

#include <fstream>


#include <set>

using namespace std;

// Simple solution based on alphabetical sorting and finding indexes mappings
long sol_simple(stringstream &python_str, pstr_vec &first_names, pstr_vec &second_names, pstr_map &names_map) {
  int sort_way = ALPHA_SORT;
  sort_names(first_names, sort_way);
  sort_names(second_names, sort_way);


  //File Handling Routine to observe present code working.

  ofstream f_alpha_sort;

  f_alpha_sort.open("f_alpha_sort.txt");

  for(int j=0;j<first_names.size();j++)
  {
    f_alpha_sort<<*first_names[j]<<" : "<<*second_names[j]<<","<<"\n";
  }

  f_alpha_sort.close();



  vector<long> first_to_second_map;
  map_names(first_names, second_names, names_map, first_to_second_map);

  vector<index_seq_type> indexes_seq;
  seq_indexes(first_to_second_map, indexes_seq);
  vector<seq_seq_type> sequences_seq;
  seq_sequences(indexes_seq, sequences_seq);

  // less than 4 fragments is considered the best (in terms of number of characters)!
  if (indexes_seq.size() < 4)
    return generate_python(python_str, indexes_seq, sequences_seq, first_names.size(), sort_way);

  sort_way = ALPHA_N_SORT;
  sort_names(first_names, sort_way);
  sort_names(second_names, sort_way);


  //File Handling Routine to observe present code working.

  ofstream f_alpha_n_sort;

  f_alpha_n_sort.open("f_alpha_n_sort.txt");

  for(int j=0;j<first_names.size();j++)
  {
    f_alpha_n_sort<<*first_names[j]<<" : "<<*second_names[j]<<","<<"\n";
  }

  f_alpha_n_sort.close();












  vector<long> first_to_second_map_n;
  map_names(first_names, second_names, names_map, first_to_second_map_n);

  vector<index_seq_type> indexes_seq_n;
  seq_indexes(first_to_second_map_n, indexes_seq_n);
  vector<seq_seq_type> sequences_seq_n;
  seq_sequences(indexes_seq_n, sequences_seq_n);

  // less than 4 fragments is considered the best (in terms of number of characters)!
  if (indexes_seq_n.size() < 4)
    return generate_python(python_str, indexes_seq_n, sequences_seq_n, first_names.size(), sort_way);

  sort_way = S_ALPHA_N_SORT;
  sort_names(first_names, sort_way);
  sort_names(second_names, sort_way);


  //File Handling Routine to observe present code working.

  // ofstream f_alpha_n_sort;

  f_alpha_n_sort.open("f_s_alpha_n_sort.txt");

  for(int j=0;j<first_names.size();j++)
  {
    f_alpha_n_sort<<*first_names[j]<<" : "<<*second_names[j]<<","<<"\n";
  }

  f_alpha_n_sort.close();


















  vector<long> first_to_second_map_s;
  map_names(first_names, second_names, names_map, first_to_second_map_s);

  vector<index_seq_type> indexes_seq_s;
  seq_indexes(first_to_second_map_s, indexes_seq_s);
  vector<seq_seq_type> sequences_seq_s;
  seq_sequences(indexes_seq_s, sequences_seq_s);

  // less than 4 fragments is considered the best (in terms of number of characters)!
  if (indexes_seq_s.size() < 4)
    return generate_python(python_str, indexes_seq_s, sequences_seq_s, first_names.size(), sort_way);

  cout << indexes_seq.size() << " +-+ " << indexes_seq_n.size() << " +-+ " << indexes_seq_s.size() << " +-+ " << endl;

  long char_cnt1;
  if (indexes_seq.size() <= indexes_seq_n.size() && indexes_seq.size() <= indexes_seq_s.size())
    char_cnt1 = generate_python(python_str, indexes_seq, sequences_seq, first_names.size(), ALPHA_SORT);
  else if (indexes_seq_n.size() <= indexes_seq_s.size())
    char_cnt1 = generate_python(python_str, indexes_seq_n, sequences_seq_n, first_names.size(), ALPHA_N_SORT);
  else
    char_cnt1 = generate_python(python_str, indexes_seq_s, sequences_seq_s, first_names.size(), S_ALPHA_N_SORT);



  pstr_vec first_names_n;
  pstr_vec second_names_n;
  first_names_n.reserve(first_names.size());
  second_names_n.reserve(second_names.size());
  for (pstr_map::iterator it = names_map.begin(); it != names_map.end(); ++it) {
    if (*it->first != *it->second) {
      first_names_n.push_back(it->first);
      second_names_n.push_back(it->second);
    }
  }

  vector<long> except_neq_indexes;
  {
    sort_names(first_names, ALPHA_SORT);
    sort_names(first_names_n, ALPHA_SORT);
    sort_names(second_names_n, ALPHA_SORT);
    int j = 0;
    for (int i = 0; i < first_names_n.size(); i++) {
      while (*second_names_n[j] < *first_names_n[i]) {
	if (j == second_names_n.size()-1)
	  break;
        j++;
      }
      if (*second_names_n[j] == *first_names_n[i]) {
	int k = i;
	while (first_names[k] != first_names_n[i])
	  k--;
        except_neq_indexes.push_back(k);
      }
    }
  }

  sort_way = ALPHA_N_SORT;
  sort_names(first_names_n, sort_way);
  sort_names(second_names_n, sort_way);



  //File Handling Routine to observe present code working.

  // ofstream f_alpha_n_sort;

  f_alpha_n_sort.open("f_neg_in_alpha_sort.txt");

  for(int j=0;j<first_names.size();j++)
  {
    f_alpha_n_sort<<*first_names[j]<<" : "<<*second_names[j]<<","<<"\n";
  }

  f_alpha_n_sort.close();





  first_to_second_map.clear();
  map_names(first_names_n, second_names_n, names_map, first_to_second_map);

  indexes_seq.clear();
  seq_indexes(first_to_second_map, indexes_seq);
  sequences_seq.clear();
  seq_sequences(indexes_seq, sequences_seq);

  string str2;
  stringstream python_str2(str2);
  long char_cnt2 = generate_python_n(python_str2, indexes_seq, sequences_seq, except_neq_indexes, first_names_n.size(), sort_way);


  pstr_vec first_names_s;
  pstr_vec second_names_s;
  set<string> first_prefix;
  set<string> second_prefix;
  set<string> first_suffix;
  set<string> second_suffix;
  first_names_s.reserve(first_names_n.size());
  second_names_s.reserve(second_names_n.size());

  // TODO: currently only suffix in the second name is implemented.
  //       therefore, the oter cases although detected, no action!
  for (int k = 0; k < first_names_n.size(); k++) {
    string* fname = first_names_n[k];
    string* sname = names_map[fname];
    int fsize = fname->size();
    int ssize = sname->size();
    if (fsize < ssize && *fname == sname->substr(ssize-fsize)) {
      second_prefix.insert(sname->substr(0, ssize-fsize));
      first_names_s.push_back(fname);
      second_names_s.push_back(sname);
    }
    else if (fsize > ssize && *sname == fname->substr(fsize-ssize)) {
      first_prefix.insert(fname->substr(0, fsize-ssize));
      first_names_s.push_back(fname);
      second_names_s.push_back(sname);
    }
    else if (fsize < ssize && *fname == sname->substr(0, fsize)) {
      second_suffix.insert(sname->substr(fsize));
    }
    else if (fsize > ssize && *sname == fname->substr(0, ssize)) {
      first_suffix.insert(fname->substr(ssize));
      first_names_s.push_back(fname);
      second_names_s.push_back(sname);
    }
    else {
      first_names_s.push_back(fname);
      second_names_s.push_back(sname);
    }
  }

  int min_size = 10000;
  int max_size = 0;
  for (set<string>::iterator it = first_prefix.begin(); it != first_prefix.end(); ++it) {
    int size = (*it).size();
    if (size > max_size)
      max_size = size;
    if (size < min_size)
      min_size = size;
    cout << "f prefix:" << *it << endl;
  }
  if (max_size > 0)
    cout << "f-pre size range = " << min_size << ".." << max_size << endl;
  min_size = 10000;
  max_size = 0;
  for (set<string>::iterator it = second_prefix.begin(); it != second_prefix.end(); ++it) {
    int size = (*it).size();
    if (size > max_size)
      max_size = size;
    if (size < min_size)
      min_size = size;
    cout << "s prefix:" << *it << endl;
  }
  if (max_size > 0)
    cout << "s-pre size range = " << min_size << ".." << max_size << endl;
  min_size = 10000;
  max_size = 0;
  for (set<string>::iterator it = first_suffix.begin(); it != first_suffix.end(); ++it) {
    cout << "f suffix:" << *it << endl;
    int size = (*it).size();
    if (size > max_size)
      max_size = size;
    if (size < min_size)
      min_size = size;
  }
  if (max_size > 0)
    cout << "f-suf size range = " << min_size << ".." << max_size << endl;
  min_size = 10000;
  max_size = 0;
  for (set<string>::iterator it = second_suffix.begin(); it != second_suffix.end(); ++it) {
    int size = (*it).size();
    if (size > max_size)
      max_size = size;
    if (size < min_size)
      min_size = size;
    cout << "s suffix:" << *it << endl;
  }
  if (max_size > 0)
    cout << "s-suf size range = " << min_size << ".." << max_size << endl;

  pstr_vec except_pstrs;
  if (first_names_s.size() < first_names_n.size()) {
    sort_names(first_names_s, ALPHA_SORT);
    sort_names(second_names_s, ALPHA_SORT);


  //File Handling Routine to observe present code working.

  // ofstream f_alpha_n_sort;

  f_alpha_n_sort.open("f_suffix_detect_alpha_n_sort.txt");

  for(int j=0;j<first_names.size();j++)
  {
    f_alpha_n_sort<<*first_names[j]<<" : "<<*second_names[j]<<","<<"\n";
  }

  f_alpha_n_sort.close();



    int i = 0;
    int j = 0;
    while (i < first_names_s.size()) {
      while (j < second_names_s.size()-1 && first_names_s[i]->at(0) > second_names_s[j]->at(0))
	j++;
      int k = j;
      while (k < second_names_s.size() && first_names_s[i]->at(0) == second_names_s[k]->at(0)) {
	if (first_names_s[i]->size() < second_names_s[k]->size() && *first_names_s[i] == second_names_s[k]->substr(0, first_names_s[i]->size())) {
	  except_pstrs.push_back(first_names_s[i]);
	  cout << "EXCEPT: " << *first_names_s[i] << endl;
	  break;
	}
	k++;
      }
      i++;
    }
  }
  
  vector<long> except_indexes;
  if (except_pstrs.size() > 0) {
    sort_names(first_names_n, ALPHA_SORT);
    //sort_names(second_names_n, ALPHA_SORT);
    sort_names(except_pstrs, ALPHA_SORT);
    int j = 0;
    for (int i = 0; i < except_pstrs.size(); i++) {
      while (*first_names_n[j] < *except_pstrs[i]) {
	if (j == first_names_n.size()-1)
	  break;
	j++;
      }
      if (first_names_n[j] == except_pstrs[i])
        except_indexes.push_back(j);
      else // should no happen!
	cout << "NOT FOUND: " << except_pstrs[i] << endl;
    }
  }

  sort_way = ALPHA_N_SORT;
  sort_names(first_names_s, sort_way);
  sort_names(second_names_s, sort_way);



  //File Handling Routine to observe present code working.

  // ofstream f_alpha_n_sort;

  f_alpha_n_sort.open("f_suffix_detect_alpha_n_sort.txt");

  for(int j=0;j<first_names.size();j++)
  {
    f_alpha_n_sort<<*first_names[j]<<" : "<<*second_names[j]<<","<<"\n";
  }

  f_alpha_n_sort.close();


  first_to_second_map.clear();
  map_names(first_names_s, second_names_s, names_map, first_to_second_map);

  int prev_size = indexes_seq.size();
  indexes_seq.clear();
  seq_indexes(first_to_second_map, indexes_seq);
  sequences_seq.clear();
  seq_sequences(indexes_seq, sequences_seq);
  cout << prev_size << " ---> " << indexes_seq.size() << endl;

  string str3;
  stringstream python_str3(str3);
  long char_cnt3 = generate_python_s(python_str3, indexes_seq, sequences_seq, except_neq_indexes, except_indexes, first_names_s.size(), sort_way);

  
  cout << char_cnt1 << " .?. " << char_cnt2 << " .?. " << char_cnt3 << endl;

  if (char_cnt2 < char_cnt1 && char_cnt2 < char_cnt3) {
    python_str.str(string());
    python_str << python_str2.rdbuf();
    return char_cnt2;
  }
  if (char_cnt3 < char_cnt1 && char_cnt3 < char_cnt2) {
    python_str.str(string());
    python_str << python_str3.rdbuf();
    return char_cnt3;
  }
  
  return char_cnt1;  
}


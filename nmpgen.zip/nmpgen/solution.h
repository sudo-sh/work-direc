#ifndef _SOLUTION_H_
#define _SOLUTION_H_

#include "global.h"
#include <sstream>

long sol_simple(std::stringstream &python_str, pstr_vec &first_names, pstr_vec &second_names, pstr_map &names_map);

// TODO: Add you complete solution function here. The interface should be the same.

#endif

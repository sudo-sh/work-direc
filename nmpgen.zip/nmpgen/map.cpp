#include "map.h"
#include <iostream>
#include <set>
#include <cstdlib>

using namespace std;

// establish the mapping between the first and second list of names
int map_names(pstr_vec &first_names, pstr_vec &second_names, pstr_map &names_map, vector<long> &first_to_second_map) {

  map<string*, long> second_names_index_map;
  for (int i = 0; i < second_names.size(); i++)
    second_names_index_map[second_names[i]] = i;

  first_to_second_map.resize(first_names.size());
  for (int i = 0; i < first_names.size(); i++)
    first_to_second_map[i] = second_names_index_map[names_map[first_names[i]]];

  return 0;
}

int num_elements(index_seq_type &is) {
  int num = is.second_index - is.first_index;
  if (num < 0)
    num = -num;
  num++;
  if (is.step > 1)
    num /= is.step;
  return num;
}

// find the sequences according the given mapping
int seq_indexes(vector<long> &first_to_second_map, vector<index_seq_type> &indexes_seq) {
  cout << "-=-=-=-=-=-=-=-=-=-= =-=-=-=-=-=-=-=-=-=-" << endl;
  index_seq_type prev1, prev2;

  prev2.first_index = first_to_second_map[0];
  prev2.second_index = prev2.first_index;
  prev2.step = 0;
  
  prev1.first_index = first_to_second_map[1];
  prev1.second_index = prev1.first_index;
  prev1.step = 0;

  long prev1_prev2_seq = prev1.first_index - prev2.first_index;

  for (int i = 2; i < first_to_second_map.size(); i++) {
    long cur_index = first_to_second_map[i];
    long cur_prev1_seq = cur_index - prev1.second_index;
    if (cur_prev1_seq == prev1.step) {
      prev1.second_index = cur_index;
    }
    else if (prev2.first_index < 0) {
      prev2 = prev1;
      prev1_prev2_seq = cur_prev1_seq;
      prev1.first_index = cur_index;
      prev1.second_index = cur_index;
      prev1.step = 0;
    }
    else if (cur_prev1_seq == prev1_prev2_seq && prev2.step == 0) {
      prev1.first_index = prev2.first_index;
      prev1.second_index = cur_index;
      prev1.step = cur_prev1_seq;
      prev2.first_index = -1;
      prev2.second_index = -1;
      prev2.step = 0;
      prev1_prev2_seq = 0;
    }
    else if (prev2.step == 0 && prev1.step == 0 && (prev1_prev2_seq == 1 || prev1_prev2_seq == -1)) {
      prev1.first_index = prev2.first_index;
      prev1.step = prev1_prev2_seq;
      cout << prev1.first_index << ":" << prev1.second_index << " -> " << prev1.step << "*" << num_elements(prev1) << endl;
      indexes_seq.push_back(prev1);
      prev2.first_index = -1;
      prev2.second_index = -1;
      prev2.step = 0;
      prev1_prev2_seq = 0;
      prev1.first_index = cur_index;
      prev1.second_index = cur_index;
      prev1.step = 0;
    }
    else {
      cout << prev2.first_index << ":" << prev2.second_index << " -> " << prev2.step << "*" << num_elements(prev2) << endl;
      indexes_seq.push_back(prev2);
      prev2 = prev1;
      prev1_prev2_seq = cur_prev1_seq;
      prev1.first_index = cur_index;
      prev1.second_index = cur_index;
      prev1.step = 0;
    }
  }
  if (prev2.first_index < 0) {
    cout << prev1.first_index << ":" << prev1.second_index << " -> " << prev1.step << "*" << num_elements(prev1) << endl;
    indexes_seq.push_back(prev1);
  }
  else if (prev2.step == 0 && prev1.step == 0 && (prev1_prev2_seq == 1 || prev1_prev2_seq == -1)) {
    prev1.first_index = prev2.first_index;
    prev1.step = prev1_prev2_seq;
    cout << prev1.first_index << ":" << prev1.second_index << " -> " << prev1.step << "*" << num_elements(prev1) << endl;
    indexes_seq.push_back(prev1);
  }
  else {
    cout << prev2.first_index << ":" << prev2.second_index << " -> " << prev2.step << "*" << num_elements(prev2) << endl;
    cout << prev1.first_index << ":" << prev1.second_index << " -> " << prev1.step << "*" << num_elements(prev1) << endl;
    indexes_seq.push_back(prev2);
    indexes_seq.push_back(prev1);
  }  
  return 0;
}

int seq_sequences(vector<index_seq_type> &indexes_seq, vector<seq_seq_type> &sequences_seq) {
  vector<long> multistep_sequences;
  int i,j,k;
  for (i = 0; i < indexes_seq.size(); i++) {
    if (abs(indexes_seq[i].step) > 1)
      multistep_sequences.push_back(i);
  }
  set<long> processed;
  for (i = 0; i < multistep_sequences.size(); i++) {
    index_seq_type cur_index_seq = indexes_seq[multistep_sequences[i]];
    if (processed.find(i) != processed.end())
      continue;
    processed.insert(i);
    seq_seq_type cur_seq_seq;
    cur_seq_seq.first_index = cur_index_seq.first_index;
    cur_seq_seq.second_index = cur_index_seq.second_index;
    cur_seq_seq.num_repeat = cur_index_seq.step;
    cur_seq_seq.seq_indexes.reserve(abs(cur_seq_seq.num_repeat));
    cur_seq_seq.seq_indexes.push_back(multistep_sequences[i]);
    for (j = i+1; j <multistep_sequences.size() && cur_seq_seq.seq_indexes.size() < abs(cur_seq_seq.num_repeat); j++) {
      if (processed.find(j) != processed.end())
        continue;
      cur_index_seq = indexes_seq[multistep_sequences[j]];
      if (cur_index_seq.step == cur_seq_seq.num_repeat && abs(cur_index_seq.first_index-cur_seq_seq.first_index) < abs(cur_seq_seq.num_repeat) && abs(cur_index_seq.second_index-cur_seq_seq.second_index) < 2*abs(cur_seq_seq.num_repeat)) {
        cur_seq_seq.seq_indexes.push_back(multistep_sequences[j]);
	if (cur_seq_seq.num_repeat >= 0) {
	  if (cur_index_seq.first_index < cur_seq_seq.first_index)
            cur_seq_seq.first_index = cur_index_seq.first_index;
	  if (cur_index_seq.second_index > cur_seq_seq.second_index)
            cur_seq_seq.second_index = cur_index_seq.second_index;
	}
	else {
	  if (cur_index_seq.first_index > cur_seq_seq.first_index)
            cur_seq_seq.first_index = cur_index_seq.first_index;
	  if (cur_index_seq.second_index < cur_seq_seq.second_index)
            cur_seq_seq.second_index = cur_index_seq.second_index;
	}
        processed.insert(j);
      }
    }
    if (cur_seq_seq.seq_indexes.size() == cur_seq_seq.num_repeat) {
      long target = 0;
      for (k = 1; k < abs(cur_seq_seq.num_repeat); k++)
	target += k;
      long first_t = 0;
      for (k = 0; k < abs(cur_seq_seq.num_repeat); k++)
	first_t += abs(indexes_seq[cur_seq_seq.seq_indexes[k]].first_index - cur_seq_seq.first_index);
      long second_t = 0;
      for (k = 0; k < abs(cur_seq_seq.num_repeat); k++)
	second_t += abs(cur_seq_seq.second_index - indexes_seq[cur_seq_seq.seq_indexes[k]].second_index);
      if (first_t == target && second_t == target) {
        cout << "successful merge: " << cur_seq_seq.first_index << "..." << cur_seq_seq.second_index << "(" << cur_seq_seq.seq_indexes.size() << ")" << endl;
	sequences_seq.push_back(cur_seq_seq);
      }
      else {
        cout << "not possible merge? " << cur_seq_seq.first_index << "..." << cur_seq_seq.second_index << "(" << cur_seq_seq.seq_indexes.size() << ")" << endl;
        cur_seq_seq.seq_indexes.clear();
      }
    }
    else {
      cout << "not complete merge: " << cur_seq_seq.first_index << "..." << cur_seq_seq.second_index << "(" << cur_seq_seq.seq_indexes.size() << ")" << endl;
      cur_seq_seq.seq_indexes.clear();
    }
  }
  return 0;
}

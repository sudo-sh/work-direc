#include "generate.h"
#include "sort.h"

using namespace std;

// function to consider reverse indexing to reduce the size of string related to index
// this should not be used for single elements, just for array ranges
string compact_index_str(long long int index, long long int last_index_plus) {
  if (index == 0)
    return "";
  if (index >= last_index_plus)
    return "";
  long long int rev_index = -(last_index_plus - index);
  string si = std::to_string(index);
  string sri = std::to_string(rev_index);
  if (sri.size() < si.size())
    return sri;
  return si;
}

// function to consider reverse indexing to reduce the size of string related to index
// this should be used for single elements
string compact_index_str_s(long long int index, long long int last_index_plus) {
  long long int rev_index = -(last_index_plus - index);
  string si = std::to_string(index);
  string sri = std::to_string(rev_index);
  if (sri.size() < si.size())
    return sri;
  return si;
}

// simple function to count non-space characters of generated python stringstream
long count_nonspace(stringstream &sstr) {
  long total = sstr.str().size();
  long numspace = 0;
  for (int i = 0; i < total; i++)
    if (std::isspace(sstr.str()[i]))
      numspace++;
  return total-numspace;
}

long generate_sequences_seq_python(stringstream &python_str, vector<seq_seq_type> &sequences_seq, long last_index_plus, map<long, string> &seq_str_map, map<long,long> &index_seq_map) {
  char cur_char = 'F';
  for (int i = 0; i < sequences_seq.size(); i++) {
    seq_seq_type cur_seq_seq = sequences_seq[i];
    if (abs(cur_seq_seq.num_repeat) == cur_seq_seq.seq_indexes.size()) {
      python_str << cur_char << "=B[" << compact_index_str(cur_seq_seq.first_index, last_index_plus) << ":";
      if (cur_seq_seq.num_repeat > 0)
        python_str << compact_index_str(cur_seq_seq.second_index+1, last_index_plus) << "]" << endl;
      else
        python_str << compact_index_str(cur_seq_seq.second_index-1, last_index_plus) << ":-1]" << endl;
      seq_str_map[i] = string(1, cur_char);
      for (int j = 0; j < cur_seq_seq.seq_indexes.size(); j++) {
	index_seq_map[cur_seq_seq.seq_indexes[j]] = i;
      }
      // TODO: check it does not pass 'Z'!
      cur_char++;
    }
  }
}

long generate_indexes_seq_python(stringstream &python_str, vector<index_seq_type> &indexes_seq, vector<seq_seq_type> &sequences_seq, long last_index_plus) {
  map<long, string> seq_str_map;
  map<long, long> index_seq_map;
  generate_sequences_seq_python(python_str, sequences_seq, last_index_plus, seq_str_map, index_seq_map);
  
  python_str << "Z=";
  for (int k = 0; k < indexes_seq.size(); k++) {
    long i1 = indexes_seq[k].first_index;
    long i2 = indexes_seq[k].second_index;
    long step = indexes_seq[k].step;
    if (k > 15 && k%128 == 0)
      python_str << endl << "Z+=";
    else if (k > 0)
      python_str << "+";
    map<long, long>::iterator index_seq_it = index_seq_map.find(k);
    if (index_seq_it != index_seq_map.end()) {
      map<long, string>::iterator seq_str_it = seq_str_map.find(index_seq_it->second);
      if (abs(step) > 1)
        python_str << seq_str_it->second << "["
		   << compact_index_str(abs(i1-sequences_seq[index_seq_it->second].first_index), 999)
		   << "::" << step << "]";
      else if (seq_str_it->second.size() > 0)
        python_str << seq_str_it->second;
    }
    else if (step == 0) {
      python_str << "[B[" << compact_index_str_s(i1,last_index_plus) << "]";
      while (k < indexes_seq.size()-1) {
	k++;
        i1 = indexes_seq[k].first_index;
        i2 = indexes_seq[k].second_index;
        step = indexes_seq[k].step;
        if (step == 0)	
          python_str << ",B[" << compact_index_str_s(i1,last_index_plus) << "]";
	else {
	  k--;
	  break;
	}
      }
      python_str << "]";
    }
    else if (step > 1)
      python_str << "B[" << compact_index_str(i1,last_index_plus) << ":"
		 << compact_index_str(i2+1,last_index_plus) << ":" << step <<  "]";
    else if (step == 1)
      python_str << "B[" << compact_index_str(i1,last_index_plus) << ":"
		 << compact_index_str(i2+1,last_index_plus) << "]";
    else
      python_str << "B[" << compact_index_str(i1,last_index_plus) << ":"
		 << compact_index_str(i2-1,last_index_plus) << ":" << step << "]";
  }
  python_str << endl;
  return 0;
}

// generate the python string to be written to file later
long generate_python(stringstream &python_str, vector<index_seq_type> &indexes_seq, vector<seq_seq_type> &sequences_seq, long last_index_plus, int sort_way) {
  // TODO: currently only (reverse) alphabetical sortings are implemented
  if (sort_way != ALPHA_SORT && sort_way != R_ALPHA_SORT && sort_way != ALPHA_N_SORT && sort_way != S_ALPHA_N_SORT)
    return -1;

  if (sort_way == ALPHA_N_SORT || sort_way == S_ALPHA_N_SORT)
    python_str << "import sys,json,re" << endl;
  else
    python_str << "import sys,json" << endl;
  python_str << "A=json.load(open(sys.argv[1]))" << endl;


  // special case when simple mapping is enough!
  if (indexes_seq.size() == 1) {
    switch (sort_way) {
      case ALPHA_N_SORT:
        python_str << "T=lambda x: re.sub(\'(\\d+)\',lambda y: y.group().zfill(9),x)" << endl;
        python_str << "json.dump(dict(zip(sorted(A[0],key=T),sorted(A[1],key=T))),open(sys.argv[2],'w'))" << endl;
        break;
      case S_ALPHA_N_SORT:
        python_str << "T=lambda x: re.sub(\'(\\d+)\',lambda y: y.group().zfill(9),x)" << endl;
        python_str << "def S(x): return len(x.split('/'))" << endl;
        python_str << "json.dump(dict(zip(sorted(sorted(A[0],key=T),key=S),sorted(sorted(A[1],key=T),key=S)),open(sys.argv[2],'w'))" << endl;
        break;
      case R_ALPHA_SORT:
        python_str << "json.dump(dict(zip(sorted(A[0])[::-1],sorted(A[1])[::-1])),open(sys.argv[2],'w'))" << endl;
        break;
      //case ALPHA_SORT:
      default:
        python_str << "json.dump(dict(zip(sorted(A[0]),sorted(A[1]))),open(sys.argv[2],'w'))" << endl;
    }
    return count_nonspace(python_str);
  }

  
  switch (sort_way) {
    case ALPHA_N_SORT:
      python_str << "T=lambda x: re.sub(\'(\\d+)\',lambda y: y.group().zfill(9),x)" << endl;
      python_str << "B=sorted(A[1],key=T)" << endl;
      break;
    case S_ALPHA_N_SORT:
      python_str << "T=lambda x: re.sub(\'(\\d+)\',lambda y: y.group().zfill(9),x)" << endl;
      python_str << "def S(x): return len(x.split('/'))" << endl;
      python_str << "B=sorted(A[1],key=T)" << endl;
      python_str << "B.sort(key=S)" << endl;
      break;
    case R_ALPHA_SORT:
      python_str << "B=sorted(A[1])[::-1]" << endl;
      break;
    //case ALPHA_SORT:
    default:
      python_str << "B=sorted(A[1])" << endl;
  }
  
  generate_indexes_seq_python(python_str, indexes_seq, sequences_seq, last_index_plus);

  switch (sort_way) {
    case ALPHA_N_SORT:
      python_str << "json.dump(dict(zip(sorted(A[0],key=T),Z)),open(sys.argv[2],'w'))" << endl;
      break;
    case S_ALPHA_N_SORT:
      python_str << "json.dump(dict(zip(sorted(sorted(A[0],key=T),key=S),Z)),open(sys.argv[2],'w'))" << endl;
      break;
    case R_ALPHA_SORT:
      python_str << "json.dump(dict(zip(sorted(A[0])[::-1],Z)),open(sys.argv[2],'w'))" << endl;
      break;
    //case ALPHA_SORT:
    default:
      python_str << "json.dump(dict(zip(sorted(A[0]),Z)),open(sys.argv[2],'w'))" << endl;
  }

  return count_nonspace(python_str);
}

// generate the python string to be written to file later, by first handling one-to-one mappings
long generate_python_n(stringstream &python_str, vector<index_seq_type> &indexes_seq, vector<seq_seq_type> &sequences_seq, vector<long> &except_neq_indexes, long last_index_plus, int sort_way) {
  // TODO: currently only (reverse) alphabetical sortings are implemented
  if (sort_way != ALPHA_SORT && sort_way != DEL_ALPHA_SORT && sort_way != DEL_ALPHA_N_SORT && sort_way != DEL_ALPHA_N2_SORT && sort_way != ALPHA_N_SORT && sort_way != S_ALPHA_N_SORT)
    return -1;

  // special case when simple mapping is enough!
  if (indexes_seq.size() == 1) {
    if (sort_way == DEL_ALPHA_N_SORT)
      python_str << "import sys,json,re" << endl;
    else
      python_str << "import sys,json" << endl;
    python_str << "A=json.load(open(sys.argv[1]))" << endl;
    python_str << "B=set(A[1])" << endl;
    python_str << "A=set(A[0])" << endl;
    python_str << "C=A&B" << endl;
    
    if (except_neq_indexes.size() > 0) {
      python_str << "I=sorted(A)" << endl;
      python_str << "C=C^{";
      python_str << "I[" << except_neq_indexes[0] << "]";
      for (int k = 1; k < except_neq_indexes.size(); k++)
        python_str << ",I[" << except_neq_indexes[k] << "]";
      python_str << "}" << endl;
    }
  
    switch(sort_way) {
      case DEL_ALPHA_SORT:
        python_str << "B=sorted(B^C)" << endl;
        python_str << "A=sorted(A^C)" << endl;
        python_str << "def S(x):" << endl;
        python_str << "  return len(x.split('/'))" << endl;
        python_str << "B.sort(key=S)" << endl;
        python_str << "A.sort(key=S)" << endl;
        break;
      case DEL_ALPHA_N_SORT:
        python_str << "def T(x):" << endl;
        python_str << "  return re.sub(\'\\[(\\d)\\]\',\'[0\\g<1>]\',x)" << endl;
        python_str << "B=sorted(B^C,key=T)" << endl;
        python_str << "A=sorted(A^C,key=T)" << endl;
        python_str << "def S(x):" << endl;
        python_str << "  return len(x.split('/'))" << endl;
        python_str << "B.sort(key=S)" << endl;
        python_str << "A.sort(key=S)" << endl;
        break;
      case DEL_ALPHA_N2_SORT:
        python_str << "def T(x):" << endl;
	python_str << "  return re.sub(\'([_\\[])(\\d(\\D|$))\',\'\\g<1>0\\g<2>]\',x)" << endl;
        python_str << "B=sorted(B^C,key=T)" << endl;
        python_str << "A=sorted(A^C,key=T)" << endl;
        python_str << "def S(x):" << endl;
        python_str << "  return len(x.split('/'))" << endl;
        python_str << "B.sort(key=S)" << endl;
        python_str << "A.sort(key=S)" << endl;
        break;
      //case ALPHA_SORT:
    default:
        python_str << "B=sorted(B^C)" << endl;
        python_str << "A=sorted(A^C)" << endl;
    }
    python_str << "C=sorted(C)" << endl;
    python_str << "json.dump(dict(zip(C+A,C+B)),open(sys.argv[2],'w'))" << endl;
    return count_nonspace(python_str);
  }


  if (sort_way == DEL_ALPHA_SORT || sort_way == ALPHA_SORT)
    python_str << "import sys,json" << endl;
  else
    python_str << "import sys,json,re" << endl;
  python_str << "A=json.load(open(sys.argv[1]))" << endl;
  python_str << "B=set(A[1])" << endl;
  python_str << "A=set(A[0])" << endl;
  python_str << "C=A&B" << endl;

  if (except_neq_indexes.size() > 0) {
    python_str << "I=sorted(A)" << endl;
    python_str << "C=C^{";
    python_str << "I[" << except_neq_indexes[0] << "]";
    for (int k = 1; k < except_neq_indexes.size(); k++)
      python_str << ",I[" << except_neq_indexes[k] << "]";
    python_str << "}" << endl;
  }
  
  switch(sort_way) {
    case DEL_ALPHA_SORT:
      python_str << "B=sorted(B^C)" << endl;
      python_str << "A=sorted(A^C)" << endl;
      python_str << "def S(x):" << endl;
      python_str << "  return len(x.split('/'))" << endl;
      python_str << "B.sort(key=S)" << endl;
      python_str << "A.sort(key=S)" << endl;
      break;
    case DEL_ALPHA_N_SORT:
      python_str << "def T(x):" << endl;
      python_str << "  return re.sub(\'\\[(\\d)\\]\',\'[0\\g<1>]\',x)" << endl;
      python_str << "B=sorted(B^C,key=T)" << endl;
      python_str << "A=sorted(A^C,key=T)" << endl;
      python_str << "def S(x):" << endl;
      python_str << "  return len(x.split('/'))" << endl;
      python_str << "B.sort(key=S)" << endl;
      python_str << "A.sort(key=S)" << endl;
      break;
    case DEL_ALPHA_N2_SORT:
      python_str << "def T(x):" << endl;
      python_str << "  return re.sub(\'([_\\[])(\\d(\\D|$))\',\'\\g<1>0\\g<2>]\',x)" << endl;
      python_str << "B=sorted(B^C,key=T)" << endl;
      python_str << "A=sorted(A^C,key=T)" << endl;
      python_str << "def S(x):" << endl;
      python_str << "  return len(x.split('/'))" << endl;
      python_str << "B.sort(key=S)" << endl;
      python_str << "A.sort(key=S)" << endl;
      break;
    case ALPHA_N_SORT:
      python_str << "T=lambda x: re.sub(\'(\\d+)\',lambda y: y.group().zfill(9),x)" << endl;
      python_str << "B=sorted(B^C,key=T)" << endl;
      python_str << "A=sorted(A^C,key=T)" << endl;
      break;
    case S_ALPHA_N_SORT:
      python_str << "T=lambda x: re.sub(\'(\\d+)\',lambda y: y.group().zfill(9),x)" << endl;
      python_str << "def S(x): return len(x.split('/'))" << endl;
      python_str << "B=sorted(B^C,key=T)" << endl;
      python_str << "A=sorted(A^C,key=T)" << endl;
      python_str << "B.sort(key=S)" << endl;
      python_str << "A.sort(key=S)" << endl;
      break;
    //case ALPHA_SORT:
    default:
      python_str << "B=sorted(B^C)" << endl;
      python_str << "A=sorted(A^C)" << endl;
  }
  python_str << "C=sorted(C)" << endl;

  generate_indexes_seq_python(python_str, indexes_seq, sequences_seq, last_index_plus);

  python_str << "json.dump(dict(zip(C+A,C+Z)),open(sys.argv[2],'w'))" << endl;

  return count_nonspace(python_str);
}

// generate the python string to be written to file later, by first handling one-to-one mappings, and then added suffixes to the second names
long generate_python_s(stringstream &python_str, vector<index_seq_type> &indexes_seq, vector<seq_seq_type> &sequences_seq, vector<long> &except_neq_indexes, vector<long> &except_indexes, long last_index_plus, int sort_way) {
  // TODO: currently only (reverse) alphabetical sortings are implemented
  if (sort_way != ALPHA_SORT && sort_way != DEL_ALPHA_SORT && sort_way != DEL_ALPHA_N_SORT && sort_way != DEL_ALPHA_N2_SORT && sort_way != ALPHA_N_SORT && sort_way != S_ALPHA_N_SORT)
    return -1;

  // special case when simple mapping is enough!
  if (indexes_seq.size() == 1) {
    if (sort_way == DEL_ALPHA_N_SORT || sort_way == DEL_ALPHA_N2_SORT)
      python_str << "import sys,json,re" << endl;
    else
      python_str << "import sys,json" << endl;
    python_str << "A=json.load(open(sys.argv[1]))" << endl;
    python_str << "B=set(A[1])" << endl;
    python_str << "A=set(A[0])" << endl;
    python_str << "C=A&B" << endl;

    if (except_neq_indexes.size() > 0) {
      python_str << "I=sorted(A)" << endl;
      python_str << "C=C^{";
      python_str << "I[" << except_neq_indexes[0] << "]";
      for (int k = 1; k < except_neq_indexes.size(); k++)
        python_str << ",I[" << except_neq_indexes[k] << "]";
      python_str << "}" << endl;
    }

python_str << "E=[]" << endl;
python_str << "D=[]" << endl;
python_str << "G=sorted(B^C)" << endl;
python_str << "F=sorted(A^C)" << endl;
  if (except_indexes.size() > 0) {
    python_str << "H=[F[i] for i in [";
    python_str << except_indexes[0];
    for (int k = 1; k < except_indexes.size(); k++)
      python_str << "," << except_indexes[k];
    python_str << "]]" << endl;
  }
python_str << "j=0" << endl;
python_str << "for s in F:" << endl;
python_str << "  l=len(s)" << endl;
python_str << "  while j<len(G)-1 and G[j]<s: j+=1" << endl;
python_str << "  k=j" << endl; 
python_str << "  t=G[k]" << endl;
python_str << "  while l<len(t) and s==t[:l]:" << endl;
if (except_indexes.size() > 0)
python_str << "    if not t[l].isalnum() and s not in H:" << endl;
// TODO: there is a way to reduce by 3 characters by using F.index(s) in H and keeping H as list of indexes
//       but runtime increases too much! possibly within our time budget...
else
python_str << "    if not t[l].isalnum():" << endl;
python_str << "      D+=[s]" << endl;
python_str << "      E+=[t]" << endl;
python_str << "      break" << endl;
python_str << "    k+=1" << endl; 
python_str << "    t=G[k]" << endl;
    
    switch(sort_way) {
      case DEL_ALPHA_SORT:
        python_str << "B=sorted(set(G)^set(E))" << endl;
        python_str << "A=sorted(set(F)^set(D))" << endl;
        python_str << "def S(x):" << endl;
        python_str << "  return len(x.split('/'))" << endl;
        python_str << "B.sort(key=S)" << endl;
        python_str << "A.sort(key=S)" << endl;
        break;
      case DEL_ALPHA_N_SORT:
        python_str << "def T(x):" << endl;
        python_str << "  return re.sub(\'\\[(\\d)\\]\',\'[0\\g<1>]\',x)" << endl;
        python_str << "B=sorted(set(G)^set(E),key=T)" << endl;
        python_str << "A=sorted(set(F)^set(D),key=T)" << endl;
        python_str << "def S(x):" << endl;
        python_str << "  return len(x.split('/'))" << endl;
        python_str << "B.sort(key=S)" << endl;
        python_str << "A.sort(key=S)" << endl;
        break;
      case DEL_ALPHA_N2_SORT:
        python_str << "def T(x):" << endl;
	python_str << "  return re.sub(\'([_\\[])(\\d(\\D|$))\',\'\\g<1>0\\g<2>]\',x)" << endl;
        python_str << "B=sorted(set(G)^set(E),key=T)" << endl;
        python_str << "A=sorted(set(F)^set(D),key=T)" << endl;
        python_str << "def S(x):" << endl;
        python_str << "  return len(x.split('/'))" << endl;
        python_str << "B.sort(key=S)" << endl;
        python_str << "A.sort(key=S)" << endl;
        break;
      //case ALPHA_SORT:
    default:
        python_str << "B=sorted(set(G)^set(E))" << endl;
        python_str << "A=sorted(set(F)^set(D))" << endl;
    }
    python_str << "C=sorted(C)" << endl;
    python_str << "json.dump(dict(zip(C+D+A,C+E+B)),open(sys.argv[2],'w'))" << endl;
    return count_nonspace(python_str);
  }


  if (sort_way == DEL_ALPHA_SORT || sort_way == ALPHA_SORT)
    python_str << "import sys,json" << endl;
  else
    python_str << "import sys,json,re" << endl;
  python_str << "A=json.load(open(sys.argv[1]))" << endl;
  python_str << "B=set(A[1])" << endl;
  python_str << "A=set(A[0])" << endl;
  python_str << "C=A&B" << endl;
  
  if (except_neq_indexes.size() > 0) {
    python_str << "I=sorted(A)" << endl;
    python_str << "C=C^{";
    python_str << "I[" << except_neq_indexes[0] << "]";
    for (int k = 1; k < except_neq_indexes.size(); k++)
      python_str << ",I[" << except_neq_indexes[k] << "]";
    python_str << "}" << endl;
  }

python_str << "E=[]" << endl;
python_str << "D=[]" << endl;
python_str << "G=sorted(B^C)" << endl;
python_str << "F=sorted(A^C)" << endl;
  if (except_indexes.size() > 0) {
    python_str << "H=[F[i] for i in [";
    python_str << except_indexes[0];
    for (int k = 1; k < except_indexes.size(); k++)
      python_str << "," << except_indexes[k];
    python_str << "]]" << endl;
  }
python_str << "j=0" << endl;
python_str << "for s in F:" << endl;
python_str << "  l=len(s)" << endl;
python_str << "  while j<len(G)-1 and G[j]<s: j+=1" << endl;
python_str << "  k=j" << endl; 
python_str << "  t=G[k]" << endl;
python_str << "  while l<len(t) and s==t[:l]:" << endl;
if (except_indexes.size() > 0)
python_str << "    if not t[l].isalnum() and s not in H:" << endl;
// TODO: there is a way to reduce by 3 characters by using F.index(s) in H and keeping H as list of indexes
//       but runtime increases too much! possibly within our time budget...
else
python_str << "    if not t[l].isalnum():" << endl;
python_str << "      D+=[s]" << endl;
python_str << "      E+=[t]" << endl;
python_str << "      break" << endl;
python_str << "    k+=1" << endl; 
python_str << "    t=G[k]" << endl;

  switch(sort_way) {
    case DEL_ALPHA_SORT:
      python_str << "B=sorted(set(G)^set(E))" << endl;
      python_str << "A=sorted(set(F)^set(D))" << endl;
      python_str << "def S(x):" << endl;
      python_str << "  return len(x.split('/'))" << endl;
      python_str << "B.sort(key=S)" << endl;
      python_str << "A.sort(key=S)" << endl;
      break;
    case DEL_ALPHA_N_SORT:
      python_str << "def T(x):" << endl;
      python_str << "  return re.sub(\'\\[(\\d)\\]\',\'[0\\g<1>]\',x)" << endl;
      python_str << "B=sorted(set(G)^set(E),key=T)" << endl;
      python_str << "A=sorted(set(F)^set(D),key=T)" << endl;
      python_str << "def S(x):" << endl;
      python_str << "  return len(x.split('/'))" << endl;
      python_str << "B.sort(key=S)" << endl;
      python_str << "A.sort(key=S)" << endl;
      break;
    case DEL_ALPHA_N2_SORT:
      python_str << "def T(x):" << endl;
      python_str << "  return re.sub(\'([_\\[])(\\d(\\D|$))\',\'\\g<1>0\\g<2>]\',x)" << endl;
      python_str << "B=sorted(set(G)^set(E),key=T)" << endl;
      python_str << "A=sorted(set(F)^set(D),key=T)" << endl;
      python_str << "def S(x):" << endl;
      python_str << "  return len(x.split('/'))" << endl;
      python_str << "B.sort(key=S)" << endl;
      python_str << "A.sort(key=S)" << endl;
      break;
    case ALPHA_N_SORT:
      python_str << "T=lambda x: re.sub(\'(\\d+)\',lambda y: y.group().zfill(9),x)" << endl;
      python_str << "B=sorted(set(G)^set(E),key=T)" << endl;
      python_str << "A=sorted(set(F)^set(D),key=T)" << endl;
      break;
    case S_ALPHA_N_SORT:
      python_str << "T=lambda x: re.sub(\'(\\d+)\',lambda y: y.group().zfill(9),x)" << endl;
      python_str << "def S(x): return len(x.split('/'))" << endl;
      python_str << "B=sorted(set(G)^set(E),key=T)" << endl;
      python_str << "A=sorted(set(F)^set(D),key=T)" << endl;
      python_str << "B.sort(key=S)" << endl;
      python_str << "A.sort(key=S)" << endl;
      break;
    //case ALPHA_SORT:
    default:
      python_str << "B=sorted(set(G)^set(E))" << endl;
      python_str << "A=sorted(set(F)^set(D))" << endl;
  }
  python_str << "C=sorted(C)" << endl;

  generate_indexes_seq_python(python_str, indexes_seq, sequences_seq, last_index_plus);

  python_str << "json.dump(dict(zip(C+D+A,C+E+Z)),open(sys.argv[2],'w'))" << endl;

  return count_nonspace(python_str);
}

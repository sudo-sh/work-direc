#ifndef _GLOBAL_H_
#define _GLOBAL_H_

#include <string>
#include <vector>
#include <map>

typedef std::vector<std::string*> pstr_vec;
typedef std::map<std::string*,std::string*> pstr_map;

#endif

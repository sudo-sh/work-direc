#ifndef _SORT_H_
#define _SORT_H_

#include "global.h"

// TODO: add your sorting function indexes here:
#define ALPHA_SORT 1 // alphabetical
#define R_ALPHA_SORT 2 // reverse alphabetical
#define DEL_ALPHA_SORT 3 // number of delimiters and then alphabetical
#define DEL_ALPHA_N_SORT 4 // number of delimiters and then alphabetical (1 digit numbers become 2 digit, only [N] )
#define DEL_ALPHA_N2_SORT 5 // number of delimiters and then alphabetical (1 digit numbers become 2 digit, [N] and _Nx )
#define ALPHA_N_SORT 6 // special alphaetical sort, replacing numbers with leading 0s
#define S_ALPHA_N_SORT 7 // special alphaetical sort, replacing numbers with leading 0s, then slash

int sort_names(pstr_vec &names, int sort_way);

#endif

import sys,json,re
A=json.load(open(sys.argv[1]))
B=set(A[1])
A=set(A[0])
C=A&B
E=[]
D=[]
G=sorted(B^C)
F=sorted(A^C)
j=0
for s in F:
  l=len(s)
  while j<len(G)-1 and G[j]<s: j+=1
  k=j
  t=G[k]
  while l<len(t) and s==t[:l]:
    if not t[l].isalnum():
      D+=[s]
      E+=[t]
      break
    k+=1
    t=G[k]
T=lambda x: re.sub('(\d+)',lambda y: y.group().zfill(9),x)
B=sorted(set(G)^set(E),key=T)
A=sorted(set(F)^set(D),key=T)
C=sorted(C)
Z=B[:5284]+B[5285:5300]+[B[5284]]+B[5300:12474]+B[12475:12473:-1]+[B[12476]]+B[12478:12476:-1]+B[12479:12527]+B[12528:12531]+[B[12527]]+B[12531:12724]+B[12725:12723:-1]+B[12726:12808]+[B[12810],B[12808],B[12811],B[12809]]+B[12812:12827]+B[12828:12826:-1]+B[12829:13018]+B[13019:13017:-1]+B[13020:13218]+B[13219:13217:-1]+B[13220:13264]+B[13265:13263:-1]+B[13266:]
json.dump(dict(zip(C+D+A,C+E+Z)),open(sys.argv[2],'w'))

import sys,json
A=json.load(open(sys.argv[1]))
json.dump(dict(zip(sorted(A[0]),sorted(A[1]))),open(sys.argv[2],'w'))

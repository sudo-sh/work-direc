import sys,json,re
A=json.load(open(sys.argv[1]))
T=lambda x: re.sub('(\d+)',lambda y: y.group().zfill(9),x)
json.dump(dict(zip(sorted(A[0],key=T),sorted(A[1],key=T))),open(sys.argv[2],'w'))

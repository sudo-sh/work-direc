#include "sort.h"

#include <algorithm>
#include <iostream>

using namespace std;

// reverse alphabetical sort
struct AlphaSort {
  bool operator () (const string* lhs, const string* rhs) const {
    return *lhs < *rhs;
  }
};

// reverse alphabetical sort
struct RAlphaSort {
  bool operator () (const string* lhs, const string* rhs) const {
    return *lhs > *rhs;
  }
};

// sort based on number of delimiters and then alphabetical
struct DelAlphaSort {
  bool operator () (const string* lhs, const string* rhs) const {
    int lhs_del_num = 0;
    for (int i = 0; i < lhs->size(); i++)
      if (lhs->at(i) == '/')
	lhs_del_num++;
    int rhs_del_num = 0;
    for (int i = 0; i < rhs->size(); i++)
      if (rhs->at(i) == '/')
	rhs_del_num++;
    return lhs_del_num == rhs_del_num ? *lhs < *rhs : lhs_del_num < rhs_del_num;
  }
};

// sort based on number of delimiters and then alphabetical (1 digit numbers become 2 digit, only [N] )
struct DelAlphaNSort {
  bool operator () (const string* lhs, const string* rhs) const {
    string lhs_new;
    lhs_new.reserve(lhs->size()+10);
    int lhs_del_num = 0;
    for (int i = 0; i < lhs->size(); i++) {
      char cc = lhs->at(i); 
      if (cc == '/')
	lhs_del_num++;
      if (cc == ']' && lhs->at(i-2) == '[' && std::isdigit(lhs->at(i-1))) {
        cc = lhs->at(i-1);
	lhs_new[lhs_new.size()-1] = '0';
	lhs_new.push_back(cc);
	lhs_new.push_back(']');
      }
      else
	lhs_new.push_back(cc);
    }
    string rhs_new;
    rhs_new.reserve(rhs->size()+10);
    int rhs_del_num = 0;
    for (int i = 0; i < rhs->size(); i++) {
      char cc = rhs->at(i); 
      if (cc == '/')
	rhs_del_num++;
      if (cc == ']' && rhs->at(i-2) == '[' && std::isdigit(rhs->at(i-1))) {
        cc = rhs->at(i-1);
	rhs_new[rhs_new.size()-1] = '0';
	rhs_new.push_back(cc);
	rhs_new.push_back(']');
      }
      else
	rhs_new.push_back(cc);
    }

    return lhs_del_num == rhs_del_num ? lhs_new < rhs_new : lhs_del_num < rhs_del_num;
  }
};

// sort based on number of delimiters and then alphabetical (1 digit numbers become 2 digit, [N] and _Nx )
struct DelAlphaN2Sort {
  bool operator () (const string* lhs, const string* rhs) const {
    string lhs_new;
    lhs_new.reserve(lhs->size()+10);
    int lhs_del_num = 0;
    for (int i = 0; i < lhs->size(); i++) {
      char cc = lhs->at(i); 
      if (cc == '/')
	lhs_del_num++;
      if (cc == ']' && lhs->at(i-2) == '[' && std::isdigit(lhs->at(i-1))) {
        cc = lhs->at(i-1);
	lhs_new[lhs_new.size()-1] = '0';
	lhs_new.push_back(cc);
	lhs_new.push_back(']');
      }
      else if (i > 1 && !std::isdigit(cc) && lhs->at(i-2) == '_' && std::isdigit(lhs->at(i-1))) {
	lhs_new[lhs_new.size()-1] = '0';
	lhs_new.push_back(lhs->at(i-1));
	lhs_new.push_back(cc);
      }
      else if (i == lhs->size()-1 && lhs->at(i-1) == '_' && std::isdigit(cc)) {
	lhs_new.push_back('0');
	lhs_new.push_back(cc);
      }
      else
	lhs_new.push_back(cc);
    }
    string rhs_new;
    rhs_new.reserve(rhs->size()+10);
    int rhs_del_num = 0;
    for (int i = 0; i < rhs->size(); i++) {
      char cc = rhs->at(i); 
      if (cc == '/')
	rhs_del_num++;
      if (cc == ']' && rhs->at(i-2) == '[' && std::isdigit(rhs->at(i-1))) {
        cc = rhs->at(i-1);
	rhs_new[rhs_new.size()-1] = '0';
	rhs_new.push_back(cc);
	rhs_new.push_back(']');
      }
      else if (i > 1 && !std::isdigit(cc) && rhs->at(i-2) == '_' && std::isdigit(rhs->at(i-1))) {
	rhs_new[rhs_new.size()-1] = '0';
	rhs_new.push_back(rhs->at(i-1));
	rhs_new.push_back(cc);
      }
      else if (i == rhs->size()-1 && rhs->at(i-1) == '_' && std::isdigit(cc)) {
	rhs_new.push_back('0');
	rhs_new.push_back(cc);
      }
      else
	rhs_new.push_back(cc);
    }

    return lhs_del_num == rhs_del_num ? lhs_new < rhs_new : lhs_del_num < rhs_del_num;
  }
};

// sort alphabetical, replacing numbers with leading 0s
struct AlphaNSort {
  bool operator () (const string* lhs, const string* rhs) const {
    string lhs_new;
    lhs_new.reserve(lhs->size()+10*10);
    for (int i = 0; i < lhs->size(); i++) {
      char cc = lhs->at(i); 
      if (std::isdigit(cc)) {
	string temp;
	temp.reserve(10);
	do {
	  temp.push_back(cc);
	  i++;
	  if (i < lhs->size())
	    cc = lhs->at(i);
	  else
	    cc = ' ';
	} while (std::isdigit(cc));
	i--;
	for (int j = temp.size(); j < 9; j++)
	  lhs_new.push_back('0');
	lhs_new += temp;
      }
      else
	lhs_new.push_back(cc);
    }
    string rhs_new;
    rhs_new.reserve(rhs->size()+10);
    for (int i = 0; i < rhs->size(); i++) {
      char cc = rhs->at(i); 
      if (std::isdigit(cc)) {
	string temp;
	temp.reserve(10);
	do {
	  temp.push_back(cc);
	  i++;
	  if (i < rhs->size())
	    cc = rhs->at(i);
	  else
	    cc = ' ';
	} while (std::isdigit(cc));
	i--;
	for (int j = temp.size(); j < 9; j++)
	  rhs_new.push_back('0');
	rhs_new += temp;
      }
      else
	rhs_new.push_back(cc);
    }

    return lhs_new < rhs_new;
  }
};

// sort alphabetical, replacing numbers with leading 0s, then slash
struct SAlphaNSort {
  bool operator () (const string* lhs, const string* rhs) const {
    string lhs_new;
    lhs_new.reserve(lhs->size()+10*10);
    int lhs_del_num = 0;
    for (int i = 0; i < lhs->size(); i++) {
      char cc = lhs->at(i); 
      if (cc == '/')
	lhs_del_num++;
      if (std::isdigit(cc)) {
	string temp;
	temp.reserve(10);
	do {
	  temp.push_back(cc);
	  i++;
	  if (i < lhs->size())
	    cc = lhs->at(i);
	  else
	    cc = ' ';
	} while (std::isdigit(cc));
	i--;
	for (int j = temp.size(); j < 9; j++)
	  lhs_new.push_back('0');
	lhs_new += temp;
      }
      else
	lhs_new.push_back(cc);
    }
    string rhs_new;
    rhs_new.reserve(rhs->size()+10);
    int rhs_del_num = 0;
    for (int i = 0; i < rhs->size(); i++) {
      char cc = rhs->at(i); 
      if (cc == '/')
	rhs_del_num++;
      if (std::isdigit(cc)) {
	string temp;
	temp.reserve(10);
	do {
	  temp.push_back(cc);
	  i++;
	  if (i < rhs->size())
	    cc = rhs->at(i);
	  else
	    cc = ' ';
	} while (std::isdigit(cc));
	i--;
	for (int j = temp.size(); j < 9; j++)
	  rhs_new.push_back('0');
	rhs_new += temp;
      }
      else
	rhs_new.push_back(cc);
    }

    return lhs_del_num == rhs_del_num ? lhs_new < rhs_new : lhs_del_num < rhs_del_num;
  }
};


// TODO: add support for other sort functions here:
int sort_names(pstr_vec &names, int sort_way) {
  AlphaSort a_sort;
  RAlphaSort ra_sort;
  DelAlphaSort da_sort;
  DelAlphaNSort dan_sort;
  DelAlphaN2Sort dan2_sort;
  AlphaNSort an_sort;
  SAlphaNSort san_sort;
  switch (sort_way) {
    case R_ALPHA_SORT:
      std::sort(names.begin(), names.end(), ra_sort);
      break;
    case DEL_ALPHA_SORT:
      std::sort(names.begin(), names.end(), da_sort);
      break;
    case DEL_ALPHA_N_SORT:
      std::sort(names.begin(), names.end(), dan_sort);
      break;
    case DEL_ALPHA_N2_SORT:
      std::sort(names.begin(), names.end(), dan2_sort);
      break;
    case ALPHA_N_SORT:
      std::sort(names.begin(), names.end(), an_sort);
      break;
    case S_ALPHA_N_SORT:
      std::sort(names.begin(), names.end(), san_sort);
      break;
    //case ALPHA_SORT:
    default:
      std::sort(names.begin(), names.end(), a_sort);
  }
  return 0;
}
